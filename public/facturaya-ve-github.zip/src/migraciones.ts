// Cambios de la base de datos. Regla de oro: para cambiar algo, AGREGA una migración nueva al final;
// nunca edites las anteriores. Se aplican solas, una sola vez, en orden (no hace falta consola).
type Migracion = { id: string; sql: string[]; antes?: (db: D1Database) => Promise<void> };

// El catálogo viejo estaba vacío y guardaba el dinero como decimales. Si por algún motivo tuviera datos, NO se recrea.
async function protegerCatalogoViejo(db: D1Database) {
  const existe = await db.prepare(`SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = 'catalogo'`).first();
  if (!existe) return;
  const fila = await db.prepare(`SELECT COUNT(*) AS n FROM catalogo`).first<{ n: number }>();
  if (fila && fila.n > 0) throw new Error("El catálogo viejo tiene datos: no se recrea automáticamente.");
}

// Las tablas viejas de documentos (de Gemini) estaban vacías y guardaban dinero como decimales. Si tuvieran datos, NO se recrean.
async function protegerDocumentosViejos(db: D1Database) {
  for (const t of ["documentos", "documento_renglones", "documento_pagos"]) {
    const existe = await db.prepare(`SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?`).bind(t).first();
    if (!existe) continue;
    const fila = await db.prepare(`SELECT COUNT(*) AS n FROM ${t}`).first<{ n: number }>();
    if (fila && fila.n > 0) throw new Error(`La tabla vieja ${t} tiene datos: no se recrea automáticamente.`);
  }
}

// El instalador viejo (Gemini) dejó una tabla "compras" con otra forma. NO se borra: se aparta como "compras_vieja" (con sus datos, si los hubiera)
// para poder crear la tabla nueva sin perder nada.
async function apartarComprasViejas(db: D1Database) {
  const t = await db.prepare(`SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'compras'`).first<{ sql: string }>();
  if (t && t.sql.includes("num_factura_compra")) await db.prepare(`ALTER TABLE compras RENAME TO compras_vieja`).run();
}

export const MIGRACIONES: Migracion[] = [
  {
    id: "0001_base",
    sql: [
      `CREATE TABLE IF NOT EXISTS perfil_emisor (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        instalado INTEGER NOT NULL DEFAULT 0,
        especialidad TEXT NOT NULL DEFAULT 'SERVICIOS_EQUIPOS',
        nombre_razon_social TEXT NOT NULL,
        rif TEXT NOT NULL,
        direccion_fiscal TEXT NOT NULL,
        telefono TEXT, email TEXT, logo_base64 TEXT,
        tasa_bcv REAL NOT NULL DEFAULT 0,
        datos_pago_movil TEXT, datos_zelle TEXT, datos_binance TEXT, datos_paypal TEXT, datos_transferencia TEXT,
        prox_presupuesto INTEGER NOT NULL DEFAULT 1,
        prox_factura INTEGER NOT NULL DEFAULT 1,
        prox_nota_credito INTEGER NOT NULL DEFAULT 1)`,
      `CREATE TABLE IF NOT EXISTS usuarios (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        rol TEXT NOT NULL DEFAULT 'ADMIN',
        creado_en TEXT DEFAULT (datetime('now')))`,
      `CREATE TABLE IF NOT EXISTS sesiones (
        token_hash TEXT PRIMARY KEY,
        usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
        expira_en INTEGER NOT NULL)`,
      `CREATE TABLE IF NOT EXISTS intentos_login (
        clave TEXT PRIMARY KEY,
        fallos INTEGER NOT NULL DEFAULT 0,
        bloqueado_hasta INTEGER NOT NULL DEFAULT 0)`,
      `CREATE TABLE IF NOT EXISTS auditoria (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        usuario_id INTEGER, accion TEXT NOT NULL, detalle TEXT, ip TEXT,
        creado_en TEXT NOT NULL DEFAULT (datetime('now')))`,
    ],
  },
  {
    id: "0002_fecha_tasa_bcv",
    sql: [`ALTER TABLE perfil_emisor ADD COLUMN tasa_bcv_fecha TEXT`],
  },
  {
    id: "0003_clientes_catalogo",
    antes: protegerCatalogoViejo,
    sql: [
      `CREATE TABLE IF NOT EXISTS clientes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        rif_cedula TEXT NOT NULL UNIQUE,
        nombre_apellido TEXT NOT NULL,
        direccion TEXT, whatsapp TEXT, email TEXT,
        creado_en TEXT DEFAULT (datetime('now')))`,
      `DROP TABLE IF EXISTS catalogo`,
      // Dinero en centavos de USD (enteros). precio_centavos NULL = "se define al facturar" (solo servicios).
      `CREATE TABLE catalogo (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        codigo TEXT,
        nombre TEXT NOT NULL,
        tipo TEXT NOT NULL DEFAULT 'SERVICIO' CHECK (tipo IN ('SERVICIO', 'PRODUCTO')),
        costo_centavos INTEGER CHECK (costo_centavos IS NULL OR costo_centavos >= 0),
        precio_centavos INTEGER CHECK (precio_centavos IS NULL OR precio_centavos >= 0),
        alicuota_iva INTEGER NOT NULL DEFAULT 16 CHECK (alicuota_iva IN (0, 8, 16)),
        activo INTEGER NOT NULL DEFAULT 1)`,
      `CREATE UNIQUE INDEX idx_catalogo_codigo ON catalogo(codigo) WHERE codigo IS NOT NULL`,
    ],
  },
  {
    id: "0004_documentos",
    antes: protegerDocumentosViejos,
    sql: [
      `DROP TABLE IF EXISTS documento_pagos`,
      `DROP TABLE IF EXISTS documento_renglones`,
      `DROP TABLE IF EXISTS documentos`,
      // Modo de trabajo: PRACTICA (documentos de prueba) o REAL. Se sale de práctica una sola vez.
      `CREATE TABLE ajustes (clave TEXT PRIMARY KEY, valor TEXT NOT NULL)`,
      `INSERT INTO ajustes (clave, valor) VALUES ('modo', 'PRACTICA')`,
      // Correlativos: se suman dentro de la misma transacción que emite el documento (sin saltos ni repetidos).
      `CREATE TABLE contadores (clave TEXT PRIMARY KEY, valor INTEGER NOT NULL DEFAULT 0)`,
      `INSERT INTO contadores (clave) VALUES ('FACTURA:PRACTICA'), ('PRESUPUESTO:PRACTICA'), ('CONTROL:PRACTICA'),
        ('FACTURA:REAL'), ('PRESUPUESTO:REAL'), ('CONTROL:REAL')`,
      // Reglas fiscales como DATOS con fecha de vigencia: si la ley cambia, se agrega una fila (no se toca el código ni el historial).
      `CREATE TABLE parametros_fiscales (clave TEXT NOT NULL, vigente_desde TEXT NOT NULL, valor TEXT NOT NULL, nota TEXT,
        PRIMARY KEY (clave, vigente_desde))`,
      `INSERT INTO parametros_fiscales (clave, vigente_desde, valor, nota) VALUES
        ('iva_alicuotas_cent', '2000-01-01', '0,800,1600', 'Alícuotas de IVA permitidas (% x 100): exento, 8% y 16%'),
        ('titulo_sin_control', '2000-01-01', 'FACTURA', 'Título del PDF mientras no exista N.º de control fiscal (decisión del dueño)'),
        ('leyenda_sin_control', '2000-01-01', 'DOCUMENTO SIN NÚMERO DE CONTROL FISCAL (pendiente de imprenta digital autorizada)', 'Aviso visible en el PDF'),
        ('leyenda_cambio', '2000-01-01', 'Montos expresados en bolívares (Bs.) con su equivalente en dólares (USD) a la tasa de cambio BCV vigente a la fecha de emisión.', 'Confirmar texto con el contador'),
        ('validez_presupuesto_dias', '2000-01-01', '15', 'Días de validez de un presupuesto'),
        ('plantilla_version', '2000-01-01', '1', 'Versión de la plantilla del PDF'),
        ('max_renglones', '2000-01-01', '30', 'Máximo de renglones por documento (cuida el límite de consultas del plan gratis de Cloudflare)')`,
      `CREATE TABLE documentos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tipo TEXT NOT NULL CHECK (tipo IN ('PRESUPUESTO', 'FACTURA')),
        estado TEXT NOT NULL DEFAULT 'BORRADOR' CHECK (estado IN ('BORRADOR', 'EMITIDO', 'FACTURADO', 'ANULADO')),
        modo TEXT NOT NULL CHECK (modo IN ('PRACTICA', 'REAL')),
        numero INTEGER, control_interno INTEGER, control_fiscal TEXT,
        presupuesto_id INTEGER REFERENCES documentos(id),
        cliente_id INTEGER REFERENCES clientes(id),
        cliente_rif TEXT, cliente_nombre TEXT, cliente_direccion TEXT, cliente_whatsapp TEXT, cliente_email TEXT,
        nota TEXT,
        fecha_emision TEXT, emitido_en TEXT,
        tasa_e8 INTEGER, tasa_cargada_en TEXT,
        subtotal_usd INTEGER, iva_usd INTEGER, total_usd INTEGER,
        subtotal_bs INTEGER, iva_bs INTEGER, total_bs INTEGER,
        costo_total_usd INTEGER,
        parametros_json TEXT, emisor_json TEXT,
        anulado_en TEXT, anulado_por INTEGER, motivo_anulacion TEXT,
        creado_en TEXT NOT NULL DEFAULT (datetime('now')), creado_por INTEGER)`,
      `CREATE UNIQUE INDEX idx_doc_numero ON documentos(tipo, modo, numero) WHERE numero IS NOT NULL`,
      `CREATE UNIQUE INDEX idx_doc_control ON documentos(modo, control_interno) WHERE control_interno IS NOT NULL`,
      `CREATE TABLE documento_renglones (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        documento_id INTEGER NOT NULL REFERENCES documentos(id),
        orden INTEGER NOT NULL,
        catalogo_id INTEGER REFERENCES catalogo(id),
        tipo TEXT NOT NULL CHECK (tipo IN ('SERVICIO', 'PRODUCTO')),
        descripcion TEXT NOT NULL,
        cantidad_milli INTEGER NOT NULL CHECK (cantidad_milli > 0),
        precio_usd INTEGER NOT NULL CHECK (precio_usd >= 0),
        costo_usd INTEGER,
        alicuota_cent INTEGER NOT NULL,
        monto_usd INTEGER NOT NULL,
        monto_bs INTEGER)`,
      `CREATE TABLE documento_impuestos (
        documento_id INTEGER NOT NULL REFERENCES documentos(id),
        alicuota_cent INTEGER NOT NULL,
        base_usd INTEGER NOT NULL, iva_usd INTEGER NOT NULL, base_bs INTEGER NOT NULL, iva_bs INTEGER NOT NULL,
        PRIMARY KEY (documento_id, alicuota_cent))`,
      // ---- Protecciones DENTRO de la base de datos (valen aunque la aplicación tenga un error). Solo documentos REALES.
      `CREATE TRIGGER doc_no_borrar BEFORE DELETE ON documentos
        WHEN old.modo = 'REAL' AND old.estado <> 'BORRADOR'
        BEGIN SELECT RAISE(ABORT, 'Documento emitido: no se puede borrar, solo anular.'); END`,
      `CREATE TRIGGER doc_inmutable BEFORE UPDATE ON documentos
        WHEN old.modo = 'REAL' AND old.estado <> 'BORRADOR' AND (
          old.estado = 'ANULADO'
          OR new.estado NOT IN ('EMITIDO', 'FACTURADO', 'ANULADO')
          OR (old.estado = 'FACTURADO' AND new.estado <> 'FACTURADO')
          OR new.tipo IS NOT old.tipo
  OR new.modo IS NOT old.modo
  OR new.numero IS NOT old.numero
  OR new.control_interno IS NOT old.control_interno
  OR new.presupuesto_id IS NOT old.presupuesto_id
  OR new.cliente_id IS NOT old.cliente_id
  OR new.cliente_rif IS NOT old.cliente_rif
  OR new.cliente_nombre IS NOT old.cliente_nombre
  OR new.cliente_direccion IS NOT old.cliente_direccion
  OR new.cliente_whatsapp IS NOT old.cliente_whatsapp
  OR new.cliente_email IS NOT old.cliente_email
  OR new.nota IS NOT old.nota
  OR new.fecha_emision IS NOT old.fecha_emision
  OR new.emitido_en IS NOT old.emitido_en
  OR new.tasa_e8 IS NOT old.tasa_e8
  OR new.tasa_cargada_en IS NOT old.tasa_cargada_en
  OR new.subtotal_usd IS NOT old.subtotal_usd
  OR new.iva_usd IS NOT old.iva_usd
  OR new.total_usd IS NOT old.total_usd
  OR new.subtotal_bs IS NOT old.subtotal_bs
  OR new.iva_bs IS NOT old.iva_bs
  OR new.total_bs IS NOT old.total_bs
  OR new.costo_total_usd IS NOT old.costo_total_usd
  OR new.parametros_json IS NOT old.parametros_json
  OR new.emisor_json IS NOT old.emisor_json
  OR new.creado_en IS NOT old.creado_en
  OR new.creado_por IS NOT old.creado_por)
        BEGIN SELECT RAISE(ABORT, 'Documento emitido: no se puede modificar, solo anular.'); END`,
      `CREATE TRIGGER documento_renglones_insert_emitido BEFORE INSERT ON documento_renglones
        WHEN (SELECT estado FROM documentos WHERE id = new.documento_id) <> 'BORRADOR'
         AND (SELECT modo FROM documentos WHERE id = new.documento_id) = 'REAL'
        BEGIN SELECT RAISE(ABORT, 'Documento emitido: sus renglones no se pueden cambiar.'); END`,
      `CREATE TRIGGER documento_renglones_update_emitido BEFORE UPDATE ON documento_renglones
        WHEN (SELECT estado FROM documentos WHERE id = old.documento_id) <> 'BORRADOR'
         AND (SELECT modo FROM documentos WHERE id = old.documento_id) = 'REAL'
        BEGIN SELECT RAISE(ABORT, 'Documento emitido: sus renglones no se pueden cambiar.'); END`,
      `CREATE TRIGGER documento_renglones_delete_emitido BEFORE DELETE ON documento_renglones
        WHEN (SELECT estado FROM documentos WHERE id = old.documento_id) <> 'BORRADOR'
         AND (SELECT modo FROM documentos WHERE id = old.documento_id) = 'REAL'
        BEGIN SELECT RAISE(ABORT, 'Documento emitido: sus renglones no se pueden cambiar.'); END`,
      `CREATE TRIGGER documento_impuestos_insert_emitido BEFORE INSERT ON documento_impuestos
        WHEN (SELECT estado FROM documentos WHERE id = new.documento_id) <> 'BORRADOR'
         AND (SELECT modo FROM documentos WHERE id = new.documento_id) = 'REAL'
        BEGIN SELECT RAISE(ABORT, 'Documento emitido: sus renglones no se pueden cambiar.'); END`,
      `CREATE TRIGGER documento_impuestos_update_emitido BEFORE UPDATE ON documento_impuestos
        WHEN (SELECT estado FROM documentos WHERE id = old.documento_id) <> 'BORRADOR'
         AND (SELECT modo FROM documentos WHERE id = old.documento_id) = 'REAL'
        BEGIN SELECT RAISE(ABORT, 'Documento emitido: sus renglones no se pueden cambiar.'); END`,
      `CREATE TRIGGER documento_impuestos_delete_emitido BEFORE DELETE ON documento_impuestos
        WHEN (SELECT estado FROM documentos WHERE id = old.documento_id) <> 'BORRADOR'
         AND (SELECT modo FROM documentos WHERE id = old.documento_id) = 'REAL'
        BEGIN SELECT RAISE(ABORT, 'Documento emitido: sus renglones no se pueden cambiar.'); END`,
    ],
  },
  {
    id: "0005_pagos",
    sql: [
      // Condición de pago: se fija al emitir la factura (contado o crédito con días de plazo).
      `ALTER TABLE documentos ADD COLUMN condicion TEXT NOT NULL DEFAULT 'CONTADO' CHECK (condicion IN ('CONTADO', 'CREDITO'))`,
      `ALTER TABLE documentos ADD COLUMN dias_credito INTEGER`,
      `ALTER TABLE documentos ADD COLUMN vence_el TEXT`,
      `DROP TRIGGER doc_inmutable`,
      // Las facturas ya emitidas (Fase 3) reciben vencimiento = su fecha de emisión (se hace con la protección apagada, antes de recrearla).
      `UPDATE documentos SET vence_el = fecha_emision WHERE tipo = 'FACTURA' AND estado <> 'BORRADOR' AND vence_el IS NULL`,
      `CREATE TRIGGER doc_inmutable BEFORE UPDATE ON documentos
        WHEN old.modo = 'REAL' AND old.estado <> 'BORRADOR' AND (
          old.estado = 'ANULADO'
          OR new.estado NOT IN ('EMITIDO', 'FACTURADO', 'ANULADO')
          OR (old.estado = 'FACTURADO' AND new.estado <> 'FACTURADO')
          OR new.tipo IS NOT old.tipo
          OR new.modo IS NOT old.modo
          OR new.numero IS NOT old.numero
          OR new.control_interno IS NOT old.control_interno
          OR new.presupuesto_id IS NOT old.presupuesto_id
          OR new.cliente_id IS NOT old.cliente_id
          OR new.cliente_rif IS NOT old.cliente_rif
          OR new.cliente_nombre IS NOT old.cliente_nombre
          OR new.cliente_direccion IS NOT old.cliente_direccion
          OR new.cliente_whatsapp IS NOT old.cliente_whatsapp
          OR new.cliente_email IS NOT old.cliente_email
          OR new.nota IS NOT old.nota
          OR new.fecha_emision IS NOT old.fecha_emision
          OR new.emitido_en IS NOT old.emitido_en
          OR new.tasa_e8 IS NOT old.tasa_e8
          OR new.tasa_cargada_en IS NOT old.tasa_cargada_en
          OR new.subtotal_usd IS NOT old.subtotal_usd
          OR new.iva_usd IS NOT old.iva_usd
          OR new.total_usd IS NOT old.total_usd
          OR new.subtotal_bs IS NOT old.subtotal_bs
          OR new.iva_bs IS NOT old.iva_bs
          OR new.total_bs IS NOT old.total_bs
          OR new.costo_total_usd IS NOT old.costo_total_usd
          OR new.parametros_json IS NOT old.parametros_json
          OR new.emisor_json IS NOT old.emisor_json
          OR new.creado_en IS NOT old.creado_en
          OR new.creado_por IS NOT old.creado_por
          OR new.condicion IS NOT old.condicion
          OR new.dias_credito IS NOT old.dias_credito
          OR new.vence_el IS NOT old.vence_el)
        BEGIN SELECT RAISE(ABORT, 'Documento emitido: no se puede modificar, solo anular.'); END`,
      // Pagos: el saldo NO se guarda, se calcula (total - pagos vigentes), así nunca puede quedar desfasado.
      `CREATE TABLE pagos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        documento_id INTEGER NOT NULL REFERENCES documentos(id),
        modo TEXT NOT NULL CHECK (modo IN ('PRACTICA', 'REAL')),
        numero INTEGER,
        metodo TEXT NOT NULL CHECK (metodo IN ('PAGO_MOVIL', 'TRANSFERENCIA', 'EFECTIVO', 'ZELLE', 'BINANCE', 'PAYPAL', 'OTRO')),
        moneda TEXT NOT NULL CHECK (moneda IN ('USD', 'BS')),
        monto_recibido INTEGER NOT NULL CHECK (monto_recibido > 0),
        tasa_e8 INTEGER,
        monto_usd INTEGER NOT NULL CHECK (monto_usd > 0),
        saldo_despues_usd INTEGER NOT NULL,
        referencia TEXT, nota TEXT,
        fecha_pago TEXT NOT NULL,
        registrado_en TEXT NOT NULL, registrado_por INTEGER,
        reglas_json TEXT,
        estado TEXT NOT NULL DEFAULT 'VIGENTE' CHECK (estado IN ('VIGENTE', 'ANULADO')),
        anulado_en TEXT, anulado_por INTEGER, motivo_anulacion TEXT)`,
      `CREATE UNIQUE INDEX idx_pago_numero ON pagos(modo, numero) WHERE numero IS NOT NULL`,
      `CREATE INDEX idx_pago_documento ON pagos(documento_id)`,
      `CREATE TRIGGER pago_no_borrar BEFORE DELETE ON pagos WHEN old.modo = 'REAL'
        BEGIN SELECT RAISE(ABORT, 'Un pago registrado no se borra: se anula.'); END`,
      `CREATE TRIGGER pago_inmutable BEFORE UPDATE ON pagos
        WHEN old.modo = 'REAL' AND (
          old.estado = 'ANULADO'
          OR new.estado NOT IN ('VIGENTE', 'ANULADO')
          OR new.documento_id IS NOT old.documento_id
          OR new.modo IS NOT old.modo
          OR new.numero IS NOT old.numero
          OR new.metodo IS NOT old.metodo
          OR new.moneda IS NOT old.moneda
          OR new.monto_recibido IS NOT old.monto_recibido
          OR new.tasa_e8 IS NOT old.tasa_e8
          OR new.monto_usd IS NOT old.monto_usd
          OR new.saldo_despues_usd IS NOT old.saldo_despues_usd
          OR new.referencia IS NOT old.referencia
          OR new.nota IS NOT old.nota
          OR new.fecha_pago IS NOT old.fecha_pago
          OR new.registrado_en IS NOT old.registrado_en
          OR new.registrado_por IS NOT old.registrado_por
          OR new.reglas_json IS NOT old.reglas_json)
        BEGIN SELECT RAISE(ABORT, 'Pago registrado: solo se puede anular.'); END`,
      `INSERT INTO contadores (clave) VALUES ('RECIBO:PRACTICA'), ('RECIBO:REAL')`,
      `INSERT INTO parametros_fiscales (clave, vigente_desde, valor, nota) VALUES
        ('leyenda_recibo', '2000-01-01', 'Recibo de pago: comprobante interno de cobro, sin valor fiscal.', 'Texto del recibo en PDF')`,
      // Datos de cobro con campos fijos por método (antes eran texto libre en Ajustes).
      `CREATE TABLE metodos_cobro (metodo TEXT PRIMARY KEY, activo INTEGER NOT NULL DEFAULT 0, datos_json TEXT NOT NULL DEFAULT '{}')`,
      `INSERT INTO metodos_cobro (metodo) VALUES ('PAGO_MOVIL'), ('TRANSFERENCIA'), ('ZELLE'), ('BINANCE'), ('PAYPAL'), ('EFECTIVO')`,
      // Lo que ya habías escrito en Ajustes se conserva como nota del método.
      `UPDATE metodos_cobro SET activo = 1, datos_json = json_object('nota', (SELECT datos_pago_movil FROM perfil_emisor WHERE id = 1))
        WHERE metodo = 'PAGO_MOVIL' AND (SELECT COALESCE(datos_pago_movil, '') FROM perfil_emisor WHERE id = 1) <> ''`,
      // Lo que ya habías escrito en Ajustes se conserva como nota del método.
      `UPDATE metodos_cobro SET activo = 1, datos_json = json_object('nota', (SELECT datos_transferencia FROM perfil_emisor WHERE id = 1))
        WHERE metodo = 'TRANSFERENCIA' AND (SELECT COALESCE(datos_transferencia, '') FROM perfil_emisor WHERE id = 1) <> ''`,
      // Lo que ya habías escrito en Ajustes se conserva como nota del método.
      `UPDATE metodos_cobro SET activo = 1, datos_json = json_object('nota', (SELECT datos_zelle FROM perfil_emisor WHERE id = 1))
        WHERE metodo = 'ZELLE' AND (SELECT COALESCE(datos_zelle, '') FROM perfil_emisor WHERE id = 1) <> ''`,
      // Lo que ya habías escrito en Ajustes se conserva como nota del método.
      `UPDATE metodos_cobro SET activo = 1, datos_json = json_object('nota', (SELECT datos_binance FROM perfil_emisor WHERE id = 1))
        WHERE metodo = 'BINANCE' AND (SELECT COALESCE(datos_binance, '') FROM perfil_emisor WHERE id = 1) <> ''`,
      // Lo que ya habías escrito en Ajustes se conserva como nota del método.
      `UPDATE metodos_cobro SET activo = 1, datos_json = json_object('nota', (SELECT datos_paypal FROM perfil_emisor WHERE id = 1))
        WHERE metodo = 'PAYPAL' AND (SELECT COALESCE(datos_paypal, '') FROM perfil_emisor WHERE id = 1) <> ''`,
    ],
  },
  {
    id: "0006_existencias",
    antes: apartarComprasViejas,
    sql: [
      // Control de existencias por producto. Los productos que ya tienes quedan SIN control (nada de lo que vendes hoy se bloquea)
      // hasta que cargues su cantidad; al registrar una compra o una carga, el producto pasa a controlarse.
      `ALTER TABLE catalogo ADD COLUMN controla_stock INTEGER NOT NULL DEFAULT 0`,
      `ALTER TABLE catalogo ADD COLUMN stock_minimo_milli INTEGER`,
      // Truco de seguridad: insertar aquí una fila con ok = 0 falla a propósito y deshace TODO el lote (todo o nada).
      `CREATE TABLE verificaciones (ok INTEGER NOT NULL CHECK (ok = 1))`,
      `CREATE TABLE proveedores (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        rif TEXT NOT NULL UNIQUE,
        nombre TEXT NOT NULL,
        direccion TEXT, whatsapp TEXT, email TEXT,
        creado_en TEXT DEFAULT (datetime('now')))`,
      // Factura de compra del proveedor. Los renglones quedan dentro de la compra (renglones_json) y no se pueden cambiar.
      `CREATE TABLE compras (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        modo TEXT NOT NULL CHECK (modo IN ('PRACTICA', 'REAL')),
        proveedor_id INTEGER NOT NULL REFERENCES proveedores(id),
        proveedor_rif TEXT NOT NULL, proveedor_nombre TEXT NOT NULL,
        factura_numero TEXT NOT NULL, control_numero TEXT,
        fecha TEXT NOT NULL,
        estado TEXT NOT NULL DEFAULT 'REGISTRADA' CHECK (estado IN ('REGISTRADA', 'ANULADA')),
        subtotal_usd INTEGER NOT NULL, iva_usd INTEGER NOT NULL, total_usd INTEGER NOT NULL,
        nota TEXT, renglones_json TEXT NOT NULL,
        registrado_en TEXT NOT NULL, registrado_por INTEGER,
        anulado_en TEXT, anulado_por INTEGER, motivo_anulacion TEXT)`,
      `CREATE UNIQUE INDEX idx_compra_factura ON compras(proveedor_id, factura_numero) WHERE estado = 'REGISTRADA'`,
      // Libro de existencias: cada entrada o salida es un movimiento que NUNCA se edita ni se borra (se corrige con otro).
      // Existencias = suma de cantidades; valor = suma de valores; costo promedio = valor / existencias.
      `CREATE TABLE movimientos_stock (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        producto_id INTEGER NOT NULL REFERENCES catalogo(id),
        modo TEXT NOT NULL CHECK (modo IN ('PRACTICA', 'REAL')),
        tipo TEXT NOT NULL CHECK (tipo IN ('COMPRA', 'CARGA', 'VENTA', 'DEVOLUCION_VENTA', 'ANULACION_COMPRA', 'AJUSTE')),
        motivo TEXT CHECK (motivo IS NULL OR motivo IN ('DANADO', 'PERDIDO', 'GARANTIA', 'USO_INTERNO', 'SOBRANTE')),
        cantidad_milli INTEGER NOT NULL CHECK (cantidad_milli <> 0),
        valor_usd INTEGER NOT NULL,
        documento_id INTEGER REFERENCES documentos(id),
        compra_id INTEGER REFERENCES compras(id),
        nota TEXT,
        fecha TEXT NOT NULL, creado_en TEXT NOT NULL, creado_por INTEGER)`,
      `CREATE INDEX idx_mov_producto ON movimientos_stock(producto_id)`,
      `CREATE INDEX idx_mov_documento ON movimientos_stock(documento_id)`,
      `CREATE TRIGGER mov_no_cambiar BEFORE UPDATE ON movimientos_stock WHEN old.modo = 'REAL'
        BEGIN SELECT RAISE(ABORT, 'Un movimiento de existencias no se modifica: se corrige con otro movimiento.'); END`,
      `CREATE TRIGGER mov_no_borrar BEFORE DELETE ON movimientos_stock WHEN old.modo = 'REAL'
        BEGIN SELECT RAISE(ABORT, 'Un movimiento de existencias no se borra: se corrige con otro movimiento.'); END`,
      `CREATE TRIGGER compra_no_borrar BEFORE DELETE ON compras WHEN old.modo = 'REAL'
        BEGIN SELECT RAISE(ABORT, 'Una compra registrada no se borra: se anula.'); END`,
      `CREATE TRIGGER compra_inmutable BEFORE UPDATE ON compras
        WHEN old.modo = 'REAL' AND (
          old.estado = 'ANULADA'
          OR new.estado NOT IN ('REGISTRADA', 'ANULADA')
          OR new.modo IS NOT old.modo OR new.proveedor_id IS NOT old.proveedor_id OR new.proveedor_rif IS NOT old.proveedor_rif
          OR new.proveedor_nombre IS NOT old.proveedor_nombre OR new.factura_numero IS NOT old.factura_numero OR new.control_numero IS NOT old.control_numero
          OR new.fecha IS NOT old.fecha OR new.subtotal_usd IS NOT old.subtotal_usd OR new.iva_usd IS NOT old.iva_usd OR new.total_usd IS NOT old.total_usd
          OR new.nota IS NOT old.nota OR new.renglones_json IS NOT old.renglones_json OR new.registrado_en IS NOT old.registrado_en OR new.registrado_por IS NOT old.registrado_por)
        BEGIN SELECT RAISE(ABORT, 'Compra registrada: solo se puede anular.'); END`,
      `INSERT INTO parametros_fiscales (clave, vigente_desde, valor, nota) VALUES
        ('motivos_ajuste', '2000-01-01', 'DANADO,PERDIDO,GARANTIA,USO_INTERNO,SOBRANTE', 'Motivos permitidos para ajustar existencias')`,
    ],
  },
  {
    // Fase 6.1: las compras guardan la tasa BCV de la fecha de la factura y sus montos en bolívares (libro de compras legal, en Bs).
    // Las compras anteriores quedan con estos campos vacíos a propósito: NO se les inventa una tasa (en modo real no se pueden tocar).
    id: "0007_compras_bs",
    sql: [
      `ALTER TABLE compras ADD COLUMN tasa_e8 INTEGER`,
      `ALTER TABLE compras ADD COLUMN subtotal_bs INTEGER`,
      `ALTER TABLE compras ADD COLUMN iva_bs INTEGER`,
      `ALTER TABLE compras ADD COLUMN total_bs INTEGER`,
      // Base e IVA por alícuota de cada compra (igual que documento_impuestos en las ventas): de aquí sale el libro de compras
      `CREATE TABLE compra_impuestos (
        compra_id INTEGER NOT NULL REFERENCES compras(id),
        alicuota_cent INTEGER NOT NULL,
        base_usd INTEGER NOT NULL, iva_usd INTEGER NOT NULL,
        base_bs INTEGER NOT NULL, iva_bs INTEGER NOT NULL,
        PRIMARY KEY (compra_id, alicuota_cent))`,
      `CREATE TRIGGER compra_impuestos_no_cambiar BEFORE UPDATE ON compra_impuestos
        WHEN (SELECT modo FROM compras WHERE id = old.compra_id) = 'REAL'
        BEGIN SELECT RAISE(ABORT, 'Compra registrada: sus impuestos no se pueden cambiar.'); END`,
      `CREATE TRIGGER compra_impuestos_no_borrar BEFORE DELETE ON compra_impuestos
        WHEN (SELECT modo FROM compras WHERE id = old.compra_id) = 'REAL'
        BEGIN SELECT RAISE(ABORT, 'Compra registrada: sus impuestos no se pueden borrar.'); END`,
      // La tasa y los montos en Bs también quedan protegidos: se vuelve a crear el candado de compras con las columnas nuevas
      `DROP TRIGGER compra_inmutable`,
      `CREATE TRIGGER compra_inmutable BEFORE UPDATE ON compras
        WHEN old.modo = 'REAL' AND (
          old.estado = 'ANULADA'
          OR new.estado NOT IN ('REGISTRADA', 'ANULADA')
          OR new.modo IS NOT old.modo OR new.proveedor_id IS NOT old.proveedor_id OR new.proveedor_rif IS NOT old.proveedor_rif
          OR new.proveedor_nombre IS NOT old.proveedor_nombre OR new.factura_numero IS NOT old.factura_numero OR new.control_numero IS NOT old.control_numero
          OR new.fecha IS NOT old.fecha OR new.subtotal_usd IS NOT old.subtotal_usd OR new.iva_usd IS NOT old.iva_usd OR new.total_usd IS NOT old.total_usd
          OR new.tasa_e8 IS NOT old.tasa_e8 OR new.subtotal_bs IS NOT old.subtotal_bs OR new.iva_bs IS NOT old.iva_bs OR new.total_bs IS NOT old.total_bs
          OR new.nota IS NOT old.nota OR new.renglones_json IS NOT old.renglones_json OR new.registrado_en IS NOT old.registrado_en OR new.registrado_por IS NOT old.registrado_por)
        BEGIN SELECT RAISE(ABORT, 'Compra registrada: solo se puede anular.'); END`,
    ],
  },
  {
    // Fase 7.1: usuarios con roles (ADMIN / SUPERVISOR / CAJERO / BODEGA), desactivar sin borrar, cambio obligatorio de clave y código de recuperación.
    // El rol 'ADMIN' de siempre sigue siendo el dueño: ninguna cuenta existente cambia ni pierde acceso.
    id: "0008_usuarios_roles",
    sql: [
      `ALTER TABLE usuarios ADD COLUMN activo INTEGER NOT NULL DEFAULT 1`,
      `ALTER TABLE usuarios ADD COLUMN debe_cambiar_clave INTEGER NOT NULL DEFAULT 0`,
      `ALTER TABLE usuarios ADD COLUMN codigo_recuperacion_hash TEXT`,
    ],
  },
  {
    // Fase 7.3: medio de facturación (máquina fiscal o imprenta digital, uno solo a la vez) y registro del número fiscal de cada factura.
    // El interruptor lo cambia solo el dueño y queda en un historial; cada factura guarda con qué medio se emitió y ese dato ya no se puede cambiar.
    id: "0009_medio_facturacion",
    sql: [
      `ALTER TABLE perfil_emisor ADD COLUMN medio_facturacion TEXT NOT NULL DEFAULT 'SIN_DEFINIR'`,
      `CREATE TABLE medio_historial (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        medio_anterior TEXT NOT NULL, medio_nuevo TEXT NOT NULL, motivo TEXT,
        cambiado_por INTEGER, cambiado_en TEXT NOT NULL)`,
      `ALTER TABLE documentos ADD COLUMN medio TEXT`,        // NULL = emitida antes de definir el medio
      `ALTER TABLE documentos ADD COLUMN fiscal_serial TEXT`, // serial de la máquina fiscal (solo máquina fiscal)
      // Un mismo número fiscal (de una misma máquina) no puede estar en dos facturas
      `CREATE UNIQUE INDEX documentos_fiscal_unico ON documentos (COALESCE(fiscal_serial, ''), control_fiscal) WHERE control_fiscal IS NOT NULL`,
      // El candado de facturas emitidas ahora también protege el medio y el número fiscal: el número fiscal solo se puede poner UNA vez (de vacío a un valor)
      `DROP TRIGGER doc_inmutable`,
      `CREATE TRIGGER doc_inmutable BEFORE UPDATE ON documentos
        WHEN old.modo = 'REAL' AND old.estado <> 'BORRADOR' AND (
          old.estado = 'ANULADO'
          OR new.estado NOT IN ('EMITIDO', 'FACTURADO', 'ANULADO')
          OR (old.estado = 'FACTURADO' AND new.estado <> 'FACTURADO')
          OR new.tipo IS NOT old.tipo
          OR new.modo IS NOT old.modo
          OR new.numero IS NOT old.numero
          OR new.control_interno IS NOT old.control_interno
          OR new.presupuesto_id IS NOT old.presupuesto_id
          OR new.cliente_id IS NOT old.cliente_id
          OR new.cliente_rif IS NOT old.cliente_rif
          OR new.cliente_nombre IS NOT old.cliente_nombre
          OR new.cliente_direccion IS NOT old.cliente_direccion
          OR new.cliente_whatsapp IS NOT old.cliente_whatsapp
          OR new.cliente_email IS NOT old.cliente_email
          OR new.nota IS NOT old.nota
          OR new.fecha_emision IS NOT old.fecha_emision
          OR new.emitido_en IS NOT old.emitido_en
          OR new.tasa_e8 IS NOT old.tasa_e8
          OR new.tasa_cargada_en IS NOT old.tasa_cargada_en
          OR new.subtotal_usd IS NOT old.subtotal_usd
          OR new.iva_usd IS NOT old.iva_usd
          OR new.total_usd IS NOT old.total_usd
          OR new.subtotal_bs IS NOT old.subtotal_bs
          OR new.iva_bs IS NOT old.iva_bs
          OR new.total_bs IS NOT old.total_bs
          OR new.costo_total_usd IS NOT old.costo_total_usd
          OR new.parametros_json IS NOT old.parametros_json
          OR new.emisor_json IS NOT old.emisor_json
          OR new.creado_en IS NOT old.creado_en
          OR new.creado_por IS NOT old.creado_por
          OR new.condicion IS NOT old.condicion
          OR new.dias_credito IS NOT old.dias_credito
          OR new.vence_el IS NOT old.vence_el
          OR new.medio IS NOT old.medio
          OR (new.control_fiscal IS NOT old.control_fiscal AND (old.control_fiscal IS NOT NULL OR old.medio IS NULL))
          OR (new.fiscal_serial IS NOT old.fiscal_serial AND (old.fiscal_serial IS NOT NULL OR old.medio IS NOT 'MAQUINA_FISCAL')))
        BEGIN SELECT RAISE(ABORT, 'Documento emitido: no se puede modificar, solo anular.'); END`,
    ],
  },
  {
    // Fase 7.3.1: la máquina fiscal se configura UNA vez (serial fijo + último número usado, para que el número fiscal sea correlativo) y la imprenta digital
    // guarda sus datos de conexión (la clave va aparte y NO sale en los respaldos).
    id: "0010_maquina_y_imprenta",
    sql: [
      `ALTER TABLE perfil_emisor ADD COLUMN maquina_serial TEXT`,
      `ALTER TABLE perfil_emisor ADD COLUMN maquina_ultimo INTEGER NOT NULL DEFAULT 0`,
      `CREATE TABLE integraciones (clave TEXT PRIMARY KEY, valor TEXT NOT NULL, actualizado_en TEXT NOT NULL)`,
    ],
  },
  {
    // Fase 8: IGTF (3%) activable/desactivable por factura y Devoluciones mediante Nota de Crédito según leyes venezolanas (SENIAT Providencia 0071).
    id: "0011_igtf_y_notas_credito",
    sql: [
      `ALTER TABLE perfil_emisor ADD COLUMN igtf_activo INTEGER NOT NULL DEFAULT 0`,
      `ALTER TABLE documentos ADD COLUMN aplica_igtf INTEGER NOT NULL DEFAULT 0`,
      `ALTER TABLE documentos ADD COLUMN igtf_alicuota_cent INTEGER NOT NULL DEFAULT 0`,
      `ALTER TABLE documentos ADD COLUMN igtf_usd INTEGER NOT NULL DEFAULT 0`,
      `ALTER TABLE documentos ADD COLUMN igtf_bs INTEGER NOT NULL DEFAULT 0`,
      `ALTER TABLE documentos ADD COLUMN es_nota_credito INTEGER NOT NULL DEFAULT 0`,
      `ALTER TABLE documentos ADD COLUMN factura_afectada_id INTEGER REFERENCES documentos(id)`,
      `ALTER TABLE documentos ADD COLUMN motivo_nc TEXT`,
      `INSERT OR IGNORE INTO contadores (clave) VALUES ('NOTA_CREDITO:PRACTICA'), ('NOTA_CREDITO:REAL')`,
      `INSERT OR IGNORE INTO parametros_fiscales (clave, vigente_desde, valor, nota) VALUES
        ('igtf_alicuota_cent', '2000-01-01', '300', 'Alícuota de IGTF (% x 100): 3% para pagos en divisas o criptoactivos')`,
      `DROP INDEX IF EXISTS idx_doc_numero`,
      `CREATE UNIQUE INDEX idx_doc_numero ON documentos(tipo, es_nota_credito, modo, numero) WHERE numero IS NOT NULL`,
      `CREATE INDEX IF NOT EXISTS idx_doc_afectada ON documentos(factura_afectada_id) WHERE factura_afectada_id IS NOT NULL`,
      `DROP TRIGGER doc_inmutable`,
      `CREATE TRIGGER doc_inmutable BEFORE UPDATE ON documentos
        WHEN old.modo = 'REAL' AND old.estado <> 'BORRADOR' AND (
          old.estado = 'ANULADO'
          OR new.estado NOT IN ('EMITIDO', 'FACTURADO', 'ANULADO')
          OR (old.estado = 'FACTURADO' AND new.estado <> 'FACTURADO')
          OR new.tipo IS NOT old.tipo
          OR new.es_nota_credito IS NOT old.es_nota_credito
          OR new.factura_afectada_id IS NOT old.factura_afectada_id
          OR new.motivo_nc IS NOT old.motivo_nc
          OR new.modo IS NOT old.modo
          OR new.numero IS NOT old.numero
          OR new.control_interno IS NOT old.control_interno
          OR new.presupuesto_id IS NOT old.presupuesto_id
          OR new.cliente_id IS NOT old.cliente_id
          OR new.cliente_rif IS NOT old.cliente_rif
          OR new.cliente_nombre IS NOT old.cliente_nombre
          OR new.cliente_direccion IS NOT old.cliente_direccion
          OR new.cliente_whatsapp IS NOT old.cliente_whatsapp
          OR new.cliente_email IS NOT old.cliente_email
          OR new.nota IS NOT old.nota
          OR new.fecha_emision IS NOT old.fecha_emision
          OR new.emitido_en IS NOT old.emitido_en
          OR new.tasa_e8 IS NOT old.tasa_e8
          OR new.tasa_cargada_en IS NOT old.tasa_cargada_en
          OR new.subtotal_usd IS NOT old.subtotal_usd
          OR new.iva_usd IS NOT old.iva_usd
          OR new.aplica_igtf IS NOT old.aplica_igtf
          OR new.igtf_alicuota_cent IS NOT old.igtf_alicuota_cent
          OR new.igtf_usd IS NOT old.igtf_usd
          OR new.total_usd IS NOT old.total_usd
          OR new.subtotal_bs IS NOT old.subtotal_bs
          OR new.iva_bs IS NOT old.iva_bs
          OR new.igtf_bs IS NOT old.igtf_bs
          OR new.total_bs IS NOT old.total_bs
          OR new.costo_total_usd IS NOT old.costo_total_usd
          OR new.parametros_json IS NOT old.parametros_json
          OR new.emisor_json IS NOT old.emisor_json
          OR new.creado_en IS NOT old.creado_en
          OR new.creado_por IS NOT old.creado_por
          OR new.condicion IS NOT old.condicion
          OR new.dias_credito IS NOT old.dias_credito
          OR new.vence_el IS NOT old.vence_el
          OR new.medio IS NOT old.medio
          OR (new.control_fiscal IS NOT old.control_fiscal AND (old.control_fiscal IS NOT NULL OR old.medio IS NULL))
          OR (new.fiscal_serial IS NOT old.fiscal_serial AND (old.fiscal_serial IS NOT NULL OR old.medio IS NOT 'MAQUINA_FISCAL')))
        BEGIN SELECT RAISE(ABORT, 'Documento emitido: no se puede modificar, solo anular.'); END`,
    ],
  },
];

export async function migrar(db: D1Database) {
  await db.prepare(
    `CREATE TABLE IF NOT EXISTS _migraciones (id TEXT PRIMARY KEY, aplicada_en TEXT NOT NULL DEFAULT (datetime('now')))`
  ).run();
  const { results } = await db.prepare(`SELECT id FROM _migraciones`).all<{ id: string }>();
  const hechas = new Set(results.map((r) => r.id));
  for (const m of MIGRACIONES) {
    if (hechas.has(m.id)) continue;
    await m.antes?.(db);
    // batch = todo o nada: si algo falla, la migración no queda a medias
    await db.batch([...m.sql.map((s) => db.prepare(s)), db.prepare(`INSERT INTO _migraciones (id) VALUES (?)`).bind(m.id)]);
  }
}
