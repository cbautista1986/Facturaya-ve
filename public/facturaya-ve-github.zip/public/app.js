// Entrada de la aplicación: instalador, login, inicio y ajustes. Cada módulo vive en su propio archivo.
import { $, raiz, esc, bs, usd, fechaLocal, api, aviso, campo, enviar, navegacion, activar, fijarPermisos, puede, ERROR } from "./comun.js";
import { tarjetaRestaurar, vistaRestaurar, pantallaOcupado } from "./restaurar.js";
import { tarjetaMedio, enlazarMedio } from "./medio.js";
import { pantallaCodigo, vistaRecuperar, vistaCambiarClave, vistaUsuarios, formularioCodigo, enlazarCodigo } from "./usuarios.js";
import { vistaClientes } from "./clientes.js";
import { vistaCatalogo } from "./catalogo.js";
import { vistaFactura } from "./factura.js";
import { vistaPagos } from "./pagos.js";
import { vistaCompras, vistaProveedores, vistaExistencias } from "./compras.js";
import { vistaInformes } from "./informes.js";

const NEGOCIO = [
  ["nombre_razon_social", "🏷️ Nombre o razón social"], ["rif", "🪪 RIF o cédula"], ["direccion_fiscal", "📍 Dirección fiscal"],
  ["telefono", "📞 Teléfono"], ["email", "✉️ Correo del negocio"],
];
let estado = {};

const esEntornoPreview = location.hostname.endsWith(".run.app") || location.hostname === "localhost" || location.hostname === "127.0.0.1";
const TARJETA_GITHUB_ZIP = esEntornoPreview ? `<section class="tarjeta"><span class="etiqueta">📦 PAQUETE LISTO PARA GITHUB / CLOUDFLARE</span>
  <p class="suave">Descarga el archivo <b>.zip</b> revisado y listo con las carpetas <code>src/</code>, <code>public/</code> y configuración de Cloudflare Workers para descomprimir y subir en GitHub (<b>Add file → Upload files</b>) sin perder ningún dato de tu base D1.</p>
  <a class="boton verde" href="/facturaya-ve-github.zip" download="facturaya-ve-github.zip">⬇️ Descargar paquete para GitHub (.zip)</a></section>` : "";

function vistaInstalar() {
  raiz.innerHTML = `<section class="tarjeta"><h1>🛡️ Bienvenido</h1>
    <p class="suave">Crea tu cuenta de administrador. Esta pantalla se bloquea después.</p>
    <form id="f">
      ${campo("nombre", "👤 Nombre de tu negocio o personal", "", "text", 'required autocomplete="organization"')}
      ${campo("rif", "🪪 RIF o cédula", "", "text", 'required placeholder="J-12345678-9"')}
      ${campo("direccion", "📍 Dirección fiscal", "", "text", 'required autocomplete="street-address"')}
      ${campo("telefono", "📞 Teléfono", "", "tel", 'autocomplete="tel"')}
      ${campo("email", "✉️ Tu correo (será tu usuario)", "", "email", 'required autocomplete="username"')}
      ${campo("clave", "🔒 Contraseña (mínimo 10 caracteres)", "", "password", 'required minlength="10" autocomplete="new-password"')}
      ${ERROR}<button class="boton" type="submit">CREAR SISTEMA Y ENTRAR ➔</button>
    </form></section>${TARJETA_GITHUB_ZIP}`;
  enviar($("#f"), async (d) => { const r = await api("instalar", "POST", d); pantallaCodigo(r.codigo_recuperacion, { alContinuar: ruta }); });
}

function vistaLogin() {
  raiz.innerHTML = `<section class="tarjeta"><h1>👋 Iniciar sesión</h1><p class="suave">Entra con tu correo y contraseña.</p>
    <form id="f">
      ${campo("email", "✉️ Correo", "", "email", 'required autocomplete="username"')}
      ${campo("clave", "🔒 Contraseña", "", "password", 'required autocomplete="current-password"')}
      ${ERROR}<button class="boton" type="submit">ENTRAR ➔</button>
    </form><button class="boton contorno" id="olvide" type="button">¿Olvidaste tu contraseña?</button></section>${TARJETA_GITHUB_ZIP}`;
  $("#olvide").addEventListener("click", () => vistaRecuperar(vistaLogin));
  enviar($("#f"), async (d) => { await api("login", "POST", d); await ruta(); });
}

function vistaInicio() {
  const n = estado.negocio, tasa = Number(n.tasa_bcv) || 0;
  raiz.innerHTML = `
    <header class="encabezado"><span class="logo">🖼️</span><h1>Hola, ${esc(n.nombre_razon_social)}</h1>
      <button class="icono" id="ajustes" data-ayuda="Ajustes del negocio, datos de cobro y cerrar sesión" aria-label="Ajustes">⚙️</button></header>
    ${estado.modo === "PRACTICA" ? `<section class="aviso-practica"><b>🧪 MODO PRÁCTICA</b> · los documentos son de prueba y se borran al salir en vivo (Ajustes).</section>` : ""}
    ${estado.modo === "REAL" && estado.negocio.medio_facturacion === "SIN_DEFINIR" && puede("admin") ? `<section class="aviso-control" data-destino="#/ajustes">⚠️ Elige tu <b>medio de facturación</b> (máquina fiscal o imprenta digital) en Ajustes.</section>` : ""}
    <section class="tarjeta tasa">
      <div id="tasa-vista"><span class="etiqueta">🟢 TASA BCV</span><br><strong>${tasa ? `Bs. ${bs(tasa)}` : "Sin definir"}</strong><br>
        <small class="suave">${n.tasa_bcv_fecha ? `Actualizada: ${fechaLocal(n.tasa_bcv_fecha)}` : "Escribe la tasa de hoy"}</small></div>
      ${puede("tasa") ? `<button class="boton chico verde" id="tasa-editar" data-ayuda="Cambia la tasa BCV del día">🔄 Actualizar</button>` : ""}
      <form id="tasa-form" hidden><span class="etiqueta">🟢 TASA BCV DE HOY (Bs por USD)</span>
        <input name="tasa_bcv" inputmode="decimal" placeholder="Ej: 123,45" required aria-label="Tasa BCV">
        <button class="boton chico verde" type="submit">Guardar</button>
        <button class="boton chico contorno" type="button" id="tasa-cancelar" aria-label="Cancelar">✕</button>${ERROR}</form>
    </section>
    ${puede("admin") ? `<section class="tarjeta ganancia" data-destino="#/informes" data-nombre="Informes" data-ayuda="Informes para el contador: ventas, compras, ganancias, por cobrar e inventario"><span class="etiqueta">💰 TU GANANCIA NETA (ESTE MES)</span><strong id="gan-total">$ 0,00</strong>
      <small class="suave" id="gan-det">🟣 Servicios: $0 · 🔵 Productos: $0</small></section>` : ""}
    <div class="rejilla">
      ${puede("caja") ? `<button class="accion azul" data-destino="#/factura" data-nombre="Factura" data-ayuda="Presupuestos y facturas"><span>🧾</span>Factura<small>Presupuestos y facturas</small></button>
      <button class="accion ambar" data-destino="#/clientes" data-nombre="Clientes" data-ayuda="Tus clientes y su WhatsApp"><span>👥</span>Clientes<small>Tus clientes</small></button>
      <button class="accion verde" data-destino="#/pagos" data-nombre="Pagos" data-ayuda="Por cobrar, pagos recibidos y tus datos de cobro"><span>💳</span>Pagos<small>Cobros y por cobrar</small></button>` : ""}
      ${puede("inventario") ? `<button class="accion morado" data-destino="#/inventario" data-nombre="Inventario" data-ayuda="Tus productos y servicios"><span>📦</span>Inventario<small>Productos y servicios</small></button>` : ""}
    </div>
    <section class="tarjeta"><span class="etiqueta">🔔 ALERTAS RÁPIDAS</span><p class="suave" id="alertas-txt">Todo en orden ✅</p></section>
    ${navegacion("inicio")}`;
  $("#ajustes").addEventListener("click", () => (location.hash = "#/ajustes"));
  const editando = (si) => { $("#tasa-vista").hidden = si; $("#tasa-editar").hidden = si; $("#tasa-form").hidden = !si; if (si) $("#tasa-form input").focus(); };
  $("#tasa-editar")?.addEventListener("click", () => editando(true));
  $("#tasa-cancelar").addEventListener("click", () => editando(false));
  enviar($("#tasa-form"), async (d) => { await api("config", "PUT", { tasa_bcv: d.tasa_bcv }); aviso("Tasa actualizada ✅"); await ruta(); });
  activar();
  if (puede("admin")) api("documentos/resumen").then((r) => { // ganancia real del mes (facturas emitidas)
    $("#gan-total").textContent = usd(r.total); $("#gan-det").textContent = `🟣 Servicios: ${usd(r.servicios)} · 🔵 Productos: ${usd(r.productos)}`;
  }).catch(() => {});
  Promise.all([puede("caja") ? api("pagos/resumen").catch(() => null) : null, puede("inventario") ? api("existencias/alertas").catch(() => null) : null]).then(([r, e]) => { // por cobrar, vencido y poco stock
    const t = $("#alertas-txt"); if (!t) return;
    const lineas = [];
    if (r?.vencidas_n) lineas.push([`⚠️ ${r.vencidas_n} factura(s) vencida(s): ${usd(r.vencidas_usd)}`, "#/pagos"]);
    if (r?.por_cobrar_n) lineas.push([`💵 Por cobrar: ${usd(r.por_cobrar_usd)} en ${r.por_cobrar_n} factura(s)`, "#/pagos"]);
    if (e?.agotados) lineas.push([`📦 ${e.agotados} producto(s) agotado(s)`, "#/inventario"]);
    if (e?.bajos) lineas.push([`🔔 ${e.bajos} producto(s) con poco stock`, "#/inventario"]);
    if (!lineas.length) return;
    t.innerHTML = lineas.map(([x, ir]) => `<span class="alerta-linea" data-ir="${ir}">${esc(x)}</span>`).join("<br>");
    t.querySelectorAll(".alerta-linea").forEach((el) => el.addEventListener("click", () => (location.hash = el.dataset.ir)));
  });
}

function vistaAjustes() {
  const n = estado.negocio, admin = puede("admin");
  raiz.innerHTML = `
    <header class="encabezado"><button class="icono" id="atras" data-ayuda="Volver al inicio" aria-label="Volver">←</button><h1>Ajustes</h1></header>
    <section class="tarjeta"><h2>🔑 Mi cuenta</h2><p class="suave">${esc(estado.usuario.nombre)} · ${esc(estado.usuario.rol_nombre)}<br>${esc(estado.usuario.email)}</p>
      <button class="boton chico contorno" id="cambiar-clave" type="button">Cambiar mi contraseña</button></section>
    ${admin ? `<form id="f" class="tarjeta">
      ${NEGOCIO.map(([id, et]) => campo(id, et, n[id])).join("")}
      <label class="conmutador" for="igtf_activo">
        <span class="conmutador-txt"><span>💱 Activar IGTF (3%) por defecto</span><small>Se aplicará al crear nuevas facturas; puedes encenderlo o apagarlo en cada factura.</small></span>
        <span class="switch"><input type="checkbox" role="switch" id="igtf_activo" name="igtf_activo" ${n.igtf_activo ? "checked" : ""}><span class="switch-pista" aria-hidden="true"></span></span>
      </label>
      <p class="pista">💳 Tus datos de cobro (pago móvil, Zelle, etc.) ahora se configuran en <b>Pagos → Mis datos</b>.</p>
      ${ERROR}<button class="boton verde" type="submit">GUARDAR CAMBIOS</button>
    </form>
    <section class="tarjeta"><h2>👥 Usuarios</h2><p class="suave">Crea cuentas para tu personal (cajero, supervisor, bodega), cambia sus permisos o desactívalas.</p>
      <button class="boton chico" id="usuarios" type="button">Administrar usuarios</button></section>
    ${tarjetaMedio()}
    ${formularioCodigo()}
    ${tarjetaRestaurar()}
    ${estado.modo === "PRACTICA" ? `<section class="tarjeta"><h2>🧪 Modo práctica</h2>
      <p class="suave">Mientras estés en práctica, las facturas y presupuestos son de prueba: llevan marca de agua, no valen y se borran al salir en vivo. Cuando todo esté probado y revisado con tu contador, sal en vivo para empezar la numeración real.</p>
      <form id="vivo">
        ${campo("primer_factura", "🧾 Primer N.º de factura", "1", "text", 'inputmode="numeric" required')}
        ${campo("primer_nota_credito", "↩️ Primer N.º de nota de crédito", "1", "text", 'inputmode="numeric" required')}
        ${campo("primer_control", "🔢 Primer N.º de control interno", "1", "text", 'inputmode="numeric" required')}
        ${campo("primer_presupuesto", "📋 Primer N.º de presupuesto", "1", "text", 'inputmode="numeric" required')}
        ${campo("primer_recibo", "💵 Primer N.º de recibo de pago", "1", "text", 'inputmode="numeric" required')}
        <label class="opcion"><input type="checkbox" name="confirmo"> Entiendo que se BORRAN los documentos de práctica y que NO se puede volver atrás.</label>
        ${ERROR}<button class="boton rojo" type="submit">SALIR EN VIVO</button></form></section>`
      : `<section class="tarjeta"><h2>✅ En vivo</h2><p class="suave">El sistema está en modo real: las facturas emitidas no se pueden editar ni borrar, solo anular o ajustar con Nota de Crédito.</p></section>`}
    <section class="tarjeta"><h2>💾 Respaldo</h2><p class="suave">Descarga una copia de todos tus datos (clientes, inventario y documentos). Guárdala fuera del sistema, en un lugar seguro.</p>
      <button class="boton" id="respaldo" type="button">⬇️ Exportar respaldo</button></section>
    ${TARJETA_GITHUB_ZIP}` : ""}
    <button class="boton contorno" id="salir">Cerrar sesión</button>`;
  $("#atras").addEventListener("click", () => (location.hash = "#/inicio"));
  $("#cambiar-clave").addEventListener("click", () => vistaCambiarClave(estado, { forzado: false, alTerminar: () => { if (location.hash !== "#/ajustes") location.hash = "#/ajustes"; return ruta(); } }));
  $("#salir").addEventListener("click", async () => { await api("logout", "POST"); history.replaceState(null, "", "/"); await ruta(); });
  if (!admin) return;
  $("#usuarios").addEventListener("click", () => (location.hash = "#/usuarios"));
  enlazarCodigo(ruta);
  enlazarMedio(ruta).catch((e) => aviso(e.message));
  $("#restaurar-ir").addEventListener("click", () => (location.hash = "#/restaurar"));
  enviar($("#f"), async (d) => { d.igtf_activo = $("#igtf_activo").checked ? 1 : 0; await api("config", "PUT", d); aviso("Guardado ✅"); location.hash = "#/inicio"; });
  if ($("#vivo")) enviar($("#vivo"), async (d) => {
    await api("sistema/salir-en-vivo", "POST", { primer_factura: Number(d.primer_factura), primer_nota_credito: Number(d.primer_nota_credito || 1), primer_control: Number(d.primer_control),
      primer_presupuesto: Number(d.primer_presupuesto), primer_recibo: Number(d.primer_recibo), confirmo: d.confirmo === "on" });
    aviso("El sistema está en vivo ✅"); await ruta();
  });
  $("#respaldo").addEventListener("click", async () => {
    try {
      const r = await fetch("/api/sistema/respaldo"); if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || "No se pudo descargar el respaldo.");
      const a = document.createElement("a"); a.href = URL.createObjectURL(await r.blob()); a.download = `respaldo-${new Date().toISOString().slice(0, 10)}.json`; a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 5000); aviso("Respaldo descargado ✅");
    } catch (e) { aviso(e.message); }
  });
}

async function ruta() {
  try {
    estado = await api("estado");
    if (!estado.instalado) return vistaInstalar();
    if (!estado.sesion) return vistaLogin();
    fijarPermisos(estado.permisos);
    if (estado.restaurando && !puede("admin")) return pantallaOcupado(ruta); // se está restaurando un respaldo: solo el dueño puede hacer algo
    if (estado.usuario.debe_cambiar_clave) return vistaCambiarClave(estado, { forzado: true, alTerminar: ruta }); // clave temporal: primero elige la suya
    const [seccion, id, extra] = location.hash.replace(/^#\/?/, "").split("/");
    if (estado.restaurando && seccion !== "restaurar") return vistaRestaurar(estado, ruta); // el dueño debe terminar o cancelar la restauración a medias
    if (seccion === "restaurar") return puede("admin") ? vistaRestaurar(estado, ruta) : vistaInicio();
    if (seccion === "ajustes") return vistaAjustes();
    if (seccion === "usuarios") return puede("admin") ? await vistaUsuarios(estado) : vistaInicio();
    if (seccion === "clientes") return await vistaClientes(estado, id);
    if (seccion === "factura") return await vistaFactura(estado, id, extra);
    if (seccion === "pagos") return await vistaPagos(estado, id, extra);
    if (seccion === "compras") return await vistaCompras(estado, id);
    if (seccion === "proveedores") return await vistaProveedores(estado, id);
    if (seccion === "existencias") return await vistaExistencias(estado, id);
    if (seccion === "informes") return await vistaInformes(estado, id);
    if (seccion === "inventario" || seccion === "catalogo") return await vistaCatalogo(estado, id);
    vistaInicio();
  } catch (e) {
    raiz.innerHTML = `<section class="tarjeta"><h1>⚠️ No se pudo cargar</h1><p class="error">${esc(e.message)}</p><button class="boton" id="reintentar">Reintentar</button></section>`;
    $("#reintentar").addEventListener("click", ruta);
  }
}
window.addEventListener("hashchange", ruta);
ruta();
